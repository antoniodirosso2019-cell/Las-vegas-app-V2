## Packages
firebase | Required for Realtime Database connection
framer-motion | For smooth animations and neon pulse effects

## Notes
Firebase Database URL: https://las-vegas-poker-f2d6a-default-rtdb.europe-west1.firebasedatabase.app
Tailwind Config needs to support neon glow effects (box-shadows)
